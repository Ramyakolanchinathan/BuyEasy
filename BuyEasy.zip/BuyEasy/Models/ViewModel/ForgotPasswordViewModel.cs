﻿namespace BuyEasy.Models.ViewModel
{
    public class ForgotPasswordViewModel
    {
        public string Email { get; set; }
        public string NewPassword { get; set; }
        public string ConfirmPassword { get; set; }
    }
}
