﻿namespace BuyEasy.Models.DataModel
{
    public class ForgotPassword
    {
        public string Email { get; set; }
    }
}
